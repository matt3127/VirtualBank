package Clientes;
public class Cliente {
    private String nombre;
    private int documento;

    //Constructor de Cliente
    public Cliente(String nombre, int documento) {                       //asigno los atributos a sus respectivos parametros del constructor
        this.nombre = nombre;  
        this.documento = documento;                                     
    }
    public String getNombre() {
        return nombre;
    }
    public int getDocumento() {
        return documento;
    }
}
