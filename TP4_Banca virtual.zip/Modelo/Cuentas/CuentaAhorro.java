package Modelo.Cuentas;
import Clientes.Cliente;

public class CuentaAhorro extends CuentaBanco {
    private double tasaInteres;

    public CuentaAhorro(int numeroCuenta, Cliente cliente, double tasaInteres) {
        super(numeroCuenta, cliente, "Caja de ahorro");
        this.tasaInteres = tasaInteres;
    }

    @Override
    public void depositar(double monto) {
        balance += monto;
    }

    @Override
    public boolean retirar(double monto) {
        if (balance >= monto) {
            balance -= monto;
            return true;
        }
        return false;
    }

    public double calcularInteres() {
        return balance * tasaInteres;
    }
}
