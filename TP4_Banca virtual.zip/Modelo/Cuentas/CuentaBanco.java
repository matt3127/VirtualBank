package Modelo.Cuentas;

import Clientes.Cliente;
import Modelo.Inversiones.Inversion;
import Modelo.Transacciones.Transaccion;

import java.util.ArrayList;
import java.util.List;

public abstract class CuentaBanco {
    protected int numeroCuenta;
    protected Cliente cliente;
    protected String tipoCuenta;
    protected double balance;
    protected double balanceUsd;
    protected List<Transaccion> transacciones;
    protected List<Inversion> inversiones;
    private static int contadorCuentas=0;

    public CuentaBanco(int numeroCuenta, Cliente cliente, String tipoCuenta){
        this.numeroCuenta = numeroCuenta;
        this.cliente = cliente;
        this.tipoCuenta = tipoCuenta;
        this.balance = 0.0;
        this.balanceUsd = 0.0;
        this.transacciones = new ArrayList<>();
        this.inversiones = new ArrayList<>();
        contadorCuentas++;
    }

    //Metodos

    //DEPOSITOS Y RETIROS EN PESOS ARS--------------------------------------------------------
    //Deposito dinero
    public void depositar(double monto) {
        if (monto <= 0) {
            System.out.println("El monto a depositar debe ser mayor que cero");
            return;
        }
        balance = balance + monto;
        transacciones.add(new Transaccion("Depósito", monto));
    }

    //Retira y valida que el retiro no supere el monto en la cuenta.
    public boolean retirar(double monto){
        if (monto<=0){
            System.out.println("El monto a retirar tiene que ser mayor que 0");
            return false;
        }
        if (balance >= monto) {
            balance = balance - monto;
            transacciones.add(new Transaccion("Retiro", monto));
            return true;
        }
        return false;
    }   

    // INVERSIONES --------------------------------------------------------------------------

    public boolean altaInversion(String tipoInversion, double monto, double tasaRetorno, int diasVencimiento) {
        boolean esDolar = tipoInversion.equalsIgnoreCase("Plazo fijo en dolares");
        
        // Check if there are enough funds based on currency type
        if (esDolar && balanceUsd < monto) {
            return false;  // Not enough USD
        } else if (!esDolar && balance < monto) {
            return false;  // Not enough ARS
        }
        
        // Deduct the amount from the appropriate balance
        if (esDolar) {
            balanceUsd = balanceUsd - monto;
        } else {
            balance = balance - monto;
        }
        
        // Create and record the investment
        Inversion nueva = new Inversion(inversiones.size() + 1, tipoInversion, monto, tasaRetorno, diasVencimiento);
        inversiones.add(nueva);
        transacciones.add(new Transaccion("Nueva Inversión", monto));
        
        return true;
    }


    // Getters
    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public double getBalance() {
        return balance;
    }

    public double getBalanceUsd() {
        return balanceUsd;
    }

    public List<Transaccion> getTransacciones() {
        return transacciones;
    }

    public List<Inversion> getInversiones() {
        return inversiones;
    }

    // NUEVO. Contador estático de cuentas bancarias
    public static int getCantidadCuentasCreadas() {
        return contadorCuentas;
    }

}


