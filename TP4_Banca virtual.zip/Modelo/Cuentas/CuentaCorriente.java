package Modelo.Cuentas;
import Clientes.Cliente;

public class CuentaCorriente extends CuentaBanco {
    private double limiteSobregiro;

    public CuentaCorriente(int numeroCuenta, Cliente cliente, double limiteSobregiro) {
        super(numeroCuenta, cliente, "Cuenta Corriente");
        this.limiteSobregiro = limiteSobregiro;
    }

    @Override
    public void depositar(double monto) {
        balance += monto;
    }

    @Override
    public boolean retirar(double monto) {
        if (balance + limiteSobregiro >= monto) {
            balance -= monto;
            return true;
        }
        return false;
    }
}
