package Modelo.Inversiones;

public class Inversion {
    private int inversion;
    private String tipoInversion;
    private double monto;
    private double tasaRetorno;
    private int diasVencimiento;
    
    
    //Constructor y asignacion de atributos a los parametros del constructor.
    public Inversion(int inversion, String tipoInversion, double monto, double tasaRetorno, int diasVencimiento) {    
        this.inversion = inversion;
        this.tipoInversion = tipoInversion;
        this.monto = monto;
        this.tasaRetorno = tasaRetorno;
        this.diasVencimiento = diasVencimiento;
    }
    
    //Construccion de getters
    public String getDetalleInversion() {
        return "Inversion numero " + inversion + ": " + tipoInversion + ", Monto: " + monto + ", Vence en: " + diasVencimiento + " dias";

    }
    public double calculaRetorno(){
        return monto + (monto*tasaRetorno);
    }
    public double tasaRetorno(){
        return tasaRetorno;
    }
    public double getMonto(){
        return monto;
    }
    public int getInversion(){
        return inversion;
    }
    public String getTipoInversion(){
        return tipoInversion;
    }
    public int getDiasVencimiento() {
        return diasVencimiento;
    }

    //Setter para modificar monto
    public void actualizaValor(double nuevoValor) {
        this.monto = nuevoValor;
    }
}
