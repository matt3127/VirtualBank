package Modelo;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Clientes.Cliente;
import Modelo.Cuentas.CuentaAhorro;
import Modelo.Cuentas.CuentaBanco;
import Modelo.Cuentas.CuentaCorriente;
import Modelo.Inversiones.Inversion;
import Modelo.Transacciones.Transaccion;

public class Banco {

    private String nombreBanco;
    private List<Cliente> clientes;
    private List<CuentaBanco> cuentas;

    public Banco(String nombreBanco) {
        this.nombreBanco=nombreBanco;
        this.clientes=new ArrayList<>();
        this.cuentas=new ArrayList<>();
    }
//Metodos de gestion de clientes_______________________________________________________________________________________________________

    public Cliente buscarClientePorDocumento(int documento) {
        for (Cliente cliente : clientes) {
            if (cliente.getDocumento() == documento) {
                return cliente;
            }
        }
        return null; // Devuelve null si el cliente no está registrado
    }

    public void crearCuenta(Cliente cliente, Scanner entrada) {
        int tipo;
        do{
            System.out.println("Seleccione el tipo de cuenta: 1. Corriente, 2. Ahorro");
            tipo = entrada.nextInt();
        } while (tipo!=1 && tipo!=2);
        int numeroCuenta = cuentas.size() + 1;
        CuentaBanco nuevaCuenta;
        if (tipo==1) {
            nuevaCuenta = new CuentaCorriente(numeroCuenta,cliente, 10000000);
        } else {
            nuevaCuenta = new CuentaAhorro(numeroCuenta,cliente,0.30);
        }
        cuentas.add(nuevaCuenta);
        System.out.println("Cuenta creada exitosamente: " + nuevaCuenta.getTipoCuenta());
    }

    public void registrarCliente(String nombre, int documento, Scanner entrada) {
        for (Cliente cliente : clientes) {
            if (cliente.getDocumento() == documento) {  //agregue esto para validar si el cliente ya existe mediante su DNI
                System.out.println("Error: Ya existe un cliente con ese documento.");
                return;
            }
        }
        Cliente nuevoCliente = new Cliente(nombre, documento);
        clientes.add(nuevoCliente);
        System.out.println("Cliente registrado exitosamente.");

        // Preguntar si desea crear una cuenta
        String respuesta;
        do{
            System.out.println("¿Desea crear una cuenta bancaria ahora? (S/N)");
            respuesta = entrada.next();

        } while (!respuesta.equalsIgnoreCase("S")&& !respuesta.equalsIgnoreCase("N"));
        crearCuenta(nuevoCliente, entrada);
    }
//----------------------------------------------------------------------------------------------------------------------------------
//Gestion de depositos y retiros de clientes

    public void depositarDinero(int documentoCliente, Scanner entrada, double monto) {
        List<CuentaBanco> cuentasCliente = buscarCuentasPorCliente(documentoCliente);

        if (cuentasCliente.isEmpty()) {
            System.out.println("El cliente no tiene cuentas registradas.");
            return;
        }

        // Si el cliente solo tiene una cuenta, deposita automáticamente
        if (cuentasCliente.size() == 1) {
            cuentasCliente.get(0).depositar(monto);
            System.out.println("Depósito realizado correctamente en " + cuentasCliente.get(0).getTipoCuenta() +
                    ". Nuevo saldo: $" + cuentasCliente.get(0).getBalance());
            return;
        }

        // Si tiene varias cuentas, se le pregunta en cuál quiere depositar
        System.out.println("Seleccione la cuenta en la que desea depositar:");
        for (int i = 0; i < cuentasCliente.size(); i++) {
            System.out.println((i + 1) + ". " + cuentasCliente.get(i).getTipoCuenta() +
                    "; Saldo actual: $" + cuentasCliente.get(i).getBalance());
        }

        System.out.print("Seleccione el número de cuenta: ");
        int seleccion = entrada.nextInt();

        if (seleccion < 1 || seleccion > cuentasCliente.size()) {
            System.out.println("Selección inválida.");
            return;
        }

        CuentaBanco cuentaSeleccionada = cuentasCliente.get(seleccion - 1);
        cuentaSeleccionada.depositar(monto);

        System.out.println("Depósito realizado correctamente en " + cuentaSeleccionada.getTipoCuenta() +
                ". Nuevo saldo: $" + cuentaSeleccionada.getBalance());
    }

    public void retirarDinero(int documentoCliente, Scanner entrada, double monto) {
        List<CuentaBanco> cuentasCliente = buscarCuentasPorCliente(documentoCliente);

        if (cuentasCliente.isEmpty()) {
            System.out.println("El cliente no tiene cuentas registradas.");
            return;
        }

        // Si el cliente solo tiene una cuenta, retira automáticamente
        if (cuentasCliente.size() == 1) {
            boolean retiroExitoso = cuentasCliente.get(0).retirar(monto);
            if (retiroExitoso) {
                System.out.println("Retiro realizado correctamente en " + cuentasCliente.get(0).getTipoCuenta() +
                        ". Nuevo saldo: $" + cuentasCliente.get(0).getBalance());
            } else {
                System.out.println("Saldo insuficiente.");
            }
            return;
        }

        // Si tiene varias cuentas, se le pregunta en cuál quiere retirar
        System.out.println("Seleccione la cuenta de la que desea retirar dinero:");
        for (int i = 0; i < cuentasCliente.size(); i++) {
            System.out.println((i + 1) + ". " + cuentasCliente.get(i).getTipoCuenta() +
                    " | Saldo actual: $" + cuentasCliente.get(i).getBalance());
        }

        System.out.print("Seleccione el número de cuenta: ");
        int seleccion = entrada.nextInt();

        if (seleccion < 1 || seleccion > cuentasCliente.size()) {
            System.out.println("Selección inválida.");
            return;
        }

        CuentaBanco cuentaSeleccionada = cuentasCliente.get(seleccion - 1);
        boolean retiroExitoso = cuentaSeleccionada.retirar(monto);

        if (retiroExitoso) {
            System.out.println("Retiro realizado correctamente en " + cuentaSeleccionada.getTipoCuenta() +
                    ". Nuevo saldo: $" + cuentaSeleccionada.getBalance());
        } else {
            System.out.println("Saldo insuficiente.");
        }
    }

    public CuentaBanco buscarCuentaPorCliente(int documentoCliente) {
        for (CuentaBanco cuenta : cuentas) {
            if (cuenta.getCliente().getDocumento() == documentoCliente) {
                return cuenta;
            }
        }
        return null;
    }
    public void consultarCuentasCliente(int documentoCliente) {
        List<CuentaBanco> cuentasCliente = buscarCuentasPorCliente(documentoCliente);

        if (cuentasCliente.isEmpty()) {
            System.out.println("El cliente no tiene cuentas registradas.");
            return;
        }

        System.out.println("Cuentas del cliente:");
        for (CuentaBanco cuenta : cuentasCliente) {
            System.out.println("- " + cuenta.getTipoCuenta() +
                    "; Saldo: $" + cuenta.getBalance());
        }
    }

    public List<CuentaBanco> buscarCuentasPorCliente(int documentoCliente) {
        List<CuentaBanco> cuentasEncontradas = new ArrayList<>();

        for (CuentaBanco cuenta : cuentas) {
            if (cuenta.getCliente().getDocumento() == documentoCliente) {
                cuentasEncontradas.add(cuenta);
            }
        }

        return cuentasEncontradas;
    }

// Inversiones __________________________________________________________________________________________________________________

    public void realizarInversion(int documentoCliente, String tipoInversion, double monto, double tasaRetorno, int diasVencimiento) {
        CuentaBanco cuenta = buscarCuentaPorCliente(documentoCliente);
        if (cuenta != null) {
            boolean inversionExitosa = cuenta.altaInversion(tipoInversion, monto, tasaRetorno, diasVencimiento);
            if (inversionExitosa) {
                System.out.println("Inversión creada exitosamente. Inversión: "+tipoInversion+", $ "+monto+", Tasa: "+tasaRetorno+", Vence en: "+diasVencimiento+" días.");
            } else {
                System.out.println("Saldo insuficiente para realizar la inversión.");
            }
        } else {
            System.out.println("Cliente no tiene una cuenta registrada.");
        }
    }

    public void mostrarInversionesCliente(int documentoCliente) {
        CuentaBanco cuenta = buscarCuentaPorCliente(documentoCliente);
        if (cuenta != null) {
            List<Inversion> inversiones = cuenta.getInversiones();
            if (!inversiones.isEmpty()) {
                System.out.println("Inversiones activas de " + cuenta.getCliente().getNombre() + ":");
                for (Inversion inversion : inversiones) {
                    System.out.println(inversion.getDetalleInversion() + " | Retorno esperado: $" + inversion.calculaRetorno());
                }
            } else {
                System.out.println("No hay inversiones activas para este cliente.");
            }
        } else {
            System.out.println("Cliente no tiene una cuenta registrada.");
        }
    }
//Transacciones
    public void mostrarTransaccionesCliente(int documentoCliente) {
        CuentaBanco cuenta = buscarCuentaPorCliente(documentoCliente);
        if (cuenta != null) {
            List<Transaccion> transacciones = cuenta.getTransacciones();
            if (!transacciones.isEmpty()) {
                System.out.println("Historial de transacciones de " + cuenta.getCliente().getNombre() + ":");
                for (Transaccion transaccion : transacciones) {
                    System.out.println(transaccion.getDetalleTransaccion());
                }
            } else {
                System.out.println("No hay transacciones registradas para este cliente.");
            }
        } else {
            System.out.println("Cliente no tiene una cuenta registrada.");
        }
    }
    public void generarReporteDeCuentas() {
        try (FileWriter writer = new FileWriter("reporte_cuentas.txt")) {
            for (CuentaBanco cuenta : cuentas) {
                Cliente cliente = cuenta.getCliente();
                writer.write("Cliente " + cliente.getNombre() +
                        " | DNI: " + cliente.getDocumento() +
                        " | Cuenta: " + cuenta.getTipoCuenta() +
                        " #" + cuenta.getNumeroCuenta() +
                        " | Saldo ARS: " + cuenta.getBalance() +
                        " | Saldo USD: " + cuenta.getBalanceUsd() + "\n");
            }
            writer.write("\nTotal de cuentas: " + cuentas.size() + "\n");
            System.out.println("Creado el reporte en un archivo de texto 'reporte_cuentas.txt'");
        } catch (IOException e) {
            System.out.println("Error al generar el reporte: " + e.getMessage());
        }
    }


    //Setters y getters___________________________________________________________________________________

    public void setNombreBanco(String nombreBanco) {
        this.nombreBanco = nombreBanco;
    }
    public void agregaClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }
    public List<CuentaBanco> getCuentas() {
        return cuentas;
    }
    public void crearCuentas(List<CuentaBanco> cuentas) {
        this.cuentas = cuentas;
    }

    public void mostrarCantidadCuentas() {
        System.out.println("Total de cuentas creadas en el sistema: "+CuentaBanco.getCantidadCuentasCreadas());
    }
}
