package Modelo.Transacciones;
import java.util.Date;

public class Transaccion {
    private Date fechaTransaccion;
    private String tipoTransaccion;
    private double montoTransaccion;

    // Constructor
    public Transaccion(String tipoTransaccion, double montoTransaccion) {        
        this.fechaTransaccion = new Date(); // asigna la fecha actual a la transaccion
        this.tipoTransaccion = tipoTransaccion;
        this.montoTransaccion = montoTransaccion;
    }

    // Getters *No figuran en el UML y los voy a agregar posteriormente*
    public Date getFechaTransaccion() {
        return fechaTransaccion;
    }
    public String getTipoTransaccion() {
        return tipoTransaccion;
    }
    public double getMontoTransaccion() {
        return montoTransaccion;
    }
    
    // Metodo que muestra el detalle de la transaccion entera *Si figura en el UML*    
    public String getDetalleTransaccion() {
        return "Fecha: " + fechaTransaccion + ", Tipo: " + tipoTransaccion + ", Monto: $" + montoTransaccion;
    }
}
