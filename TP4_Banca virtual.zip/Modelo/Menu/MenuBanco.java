package Modelo.Menu;


import java.util.InputMismatchException;
import java.util.Scanner;
import Modelo.Banco;
import Clientes.Cliente;

public class MenuBanco {
    private Scanner entrada;
    private Banco miBanco;

    public MenuBanco(Banco miBanco) {
        this.miBanco = miBanco;
        this.entrada = new Scanner(System.in);
    }

    public void mostrarMenu() {
        int opcion=-1;
        do {
            System.out.println("\n---- Menú del Banco Virtual ----");
            System.out.println("1. Crear Cliente");
            System.out.println("2. Crear Cuenta");
            System.out.println("3. Depositar Dinero");
            System.out.println("4. Retirar Dinero");
            System.out.println("5. Realizar Inversión");
            System.out.println("6. Consultar Inversiones");
            System.out.println("7. Consultar Transacciones");
            System.out.println("8. Consultar Cuentas");
            System.out.println("9. Generar Reporte");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            try{
                opcion = entrada.nextInt();
                entrada.nextLine();  // Limpieza de buffer
                ejecutarOpcion(opcion);
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, ingrese un número 0 al 9");
                entrada.nextLine();
            }

        } while (opcion != 0);
        System.out.println("Gracias por usar nuestro banco.");
        entrada.close();
    }

    private void ejecutarOpcion(int opcion) {
        switch (opcion) {
            case 0:
                break;
            case 1:
                crearCliente();
                break;
            case 2:
                crearCuenta();
                break;
            case 3:
                depositarDinero();
                break;
            case 4:
                retirarDinero();
                break;
            case 5:
                realizarInversion();
                break;
            case 6:
                consultarInversiones();
                break;
            case 7:
                consultarTransacciones();
                break;
            case 8:
                consultarCuentas();
                break;
            case 9:
                miBanco.generarReporteDeCuentas();
                break;
            default:
            System.out.println("Opción no válida. Intente nuevamente.");
        }
    }

    private void crearCliente() {
        String nombre;
        do{
            System.out.print("Ingrese nombre: ");
            nombre = entrada.nextLine().trim();
        }while (nombre.isEmpty());

        System.out.print("Ingrese documento: ");
        try{
            int documento = entrada.nextInt();

            entrada.nextLine();  // Limpieza de buffer
            miBanco.registrarCliente(nombre, documento, entrada);
        } catch (InputMismatchException e){
            System.out.println("Error: Debe ingresar un documento válido con números del 0 al 9");
            entrada.nextLine();
        }
    }

    private void crearCuenta() {
        System.out.print("Ingrese el documento del cliente: ");
        int documentoCliente = entrada.nextInt();
        Cliente clienteEncontrado = miBanco.buscarClientePorDocumento(documentoCliente);

        if (clienteEncontrado != null) {
            miBanco.crearCuenta(clienteEncontrado, entrada);
        } else {
            System.out.println("Cliente no encontrado. Debe registrarse primero.");
        }
    }

    private void depositarDinero() {
        int documento=0;
        double monto=0;
        do{
            System.out.print("Ingrese el documento del cliente: ");
            documento = entrada.nextInt();
        } while (documento<1);

        do{
            System.out.print("Ingrese el monto a depositar: ");
            monto = entrada.nextDouble();
        } while (monto<1);
        miBanco.depositarDinero(documento,entrada, monto);
    }

    private void retirarDinero() {
        double monto=0;
        System.out.print("Ingrese el documento del cliente: ");
        int documento = entrada.nextInt();
        do{
            System.out.print("Ingrese el monto a retirar: ");
            monto = entrada.nextDouble();
        }while (monto<1);

        miBanco.retirarDinero(documento,entrada, monto);
    }

    private void realizarInversion() {
        System.out.print("Ingrese el documento del cliente: ");
        int documento = entrada.nextInt();
        entrada.nextLine(); // Limpiar buffer
        System.out.print("Ingrese el tipo de inversión: ");
        String tipo = entrada.nextLine();
        System.out.print("Ingrese el monto a invertir: ");
        double monto = entrada.nextDouble();
        System.out.print("Ingrese la tasa de retorno (%): ");
        double tasaRetorno = entrada.nextDouble() / 100;
        System.out.print("Ingrese la cantidad de días hasta el vencimiento: ");
        int dias = entrada.nextInt();

        miBanco.realizarInversion(documento, tipo, monto, tasaRetorno, dias);
    }

    private void consultarInversiones() {
        System.out.print("Ingrese el documento del cliente: ");
        int documento = entrada.nextInt();
        miBanco.mostrarInversionesCliente(documento);
    }

    private void consultarTransacciones() {
        System.out.print("Ingrese el documento del cliente: ");
        int documento = entrada.nextInt();
        miBanco.mostrarTransaccionesCliente(documento);
    }

    private void consultarCuentas() {
        System.out.print("Ingrese el documento del cliente: ");
        int documento = entrada.nextInt();
        miBanco.consultarCuentasCliente(documento);
    }

}
